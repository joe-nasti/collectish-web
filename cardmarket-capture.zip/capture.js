// Self-contained so the extension can run this exact parser in an isolated tab.
// Reads offer DOM only: never cookies, storage, forms, scripts or account details.
export function captureCardmarketDocument(doc, pageUrl, observedAt) {
  doc = doc || document;
  const url = new URL(pageUrl);
  if (url.protocol !== 'https:' || url.hostname !== 'www.cardmarket.com') throw Error('Open a Cardmarket seller inventory page.');
  const heading = [...doc.querySelectorAll('h1,h2,title')].map(n=>n.textContent).join(' ');
  if (/sorry, you have been blocked|verify you are human|just a moment|checking your browser|access denied/i.test(heading) || doc.querySelector('#challenge-running,#challenge-form')) {
    return {status:'blocked',message:'Cardmarket verification is required. No offers captured; saved pages are unchanged.'};
  }
  const route = url.pathname.match(/^\/(en|fr|de|es|it)\/Magic\/Users\/([a-zA-Z0-9_-]{1,80})\/Offers\/Singles\/?$/);
  if (!route) throw Error('Open a seller’s Magic singles inventory, then capture this page.');
  const allowed = ['name','idExpansions','idRarities','condition','idLanguages','comments','minPrice','maxPrice','minAmt','isFoil','isSigned','isAltered','sortBy'];
  const filters = new URLSearchParams();
  for (const key of allowed) if(url.searchParams.has(key)) filters.set(key,url.searchParams.get(key).slice(0,200));
  filters.sort();
  const page = Number(url.searchParams.get('site') || 1);
  if(!Number.isInteger(page)||page<1||page>10000) throw Error('Invalid inventory page number.');
  const source = new URL(url.origin+url.pathname); source.search=filters.toString(); if(page>1) source.searchParams.set('site',String(page));
  const text = n=>(n?.textContent||'').trim();
  const rows = [...doc.querySelectorAll('[id^="stockRow"]')].map(row=>{
    const articleId = row.id.slice(8), link=row.querySelector('a[href*="/Products/Singles/"]');
    const productUrl = link ? new URL(link.getAttribute('href'),url.origin) : null;
    const thumbnail=row.querySelector('.thumbnail-icon')?.getAttribute('data-bs-title')||'';
    const productId=thumbnail.match(/https:\/\/product-images\.s3\.cardmarket\.com\/1\/[A-Z0-9]+\/(\d+)\/\1\.jpg/i)?.[1]||null;
    const attrs=[...row.querySelectorAll('.product-attributes [title]')].map(n=>n.getAttribute('title'));
    const languages=['English','French','German','Spanish','Italian','Portuguese','Japanese','Russian','Korean','Chinese','Traditional Chinese','Simplified Chinese'];
    const language=attrs.find(t=>languages.includes(t))||'Unknown';
    const priceText=text(row.querySelector('.price-container'));
    const amount=text(row.querySelector('.col-offer .item-count'));
    const price=/^\d[\d.]*,\d{2}\s*€$/.test(priceText)?Number(priceText.replace(/\./g,'').replace(',','.').replace(/\s*€/,'')):null;
    const quantity=/^\d+$/.test(amount)?Number(amount):null;
    if(!/^\d{1,15}$/.test(articleId)||!link||!productUrl||productUrl.hostname!==url.hostname||!productUrl.pathname.includes('/Magic/Products/Singles/')||price===null||quantity===null) throw Error('An offer has an unfamiliar format. This page was not saved.');
    productUrl.search='';productUrl.hash='';
    return {article_id:articleId,product_id:productId,name:text(link).slice(0,300),expansion:row.querySelector('.expansion-symbol')?.getAttribute('title')||'',condition:text(row.querySelector('.article-condition')),language,foil:attrs.includes('Foil'),signed:attrs.includes('Signed'),altered:attrs.includes('Altered'),price_eur:price,quantity,comments:text(row.querySelector('.product-comments span:not([title])')).slice(0,500),product_url:productUrl.href,observed_at:observedAt};
  });
  const pagination=text(doc.querySelector('.pagination'));
  const hits=pagination.match(/([\d.,]+)(\+?)\s*(?:Hits|Treffer|Résultats|Resultados|Risultati)/i);
  const pageCount=pagination.match(/(?:Page|Seite|Página|Pagina)\s+\d+\s+(?:of|von|sur|de|di)\s+(\d+)(\+?)/i);
  if(!rows.length) throw Error('No readable offers on this page. Existing captures are unchanged.');
  return {status:'captured',schema:'collectish-cardmarket-page-v1',seller:route[2],scope:filters.toString(),page,url:source.href,observed_at:observedAt,total:hits?Number(hits[1].replace(/[.,]/g,'')):null,total_is_lower_bound:!hits||Boolean(hits[2]),pages:pageCount?Number(pageCount[1]):null,pages_is_lower_bound:!pageCount||Boolean(pageCount[2]),rows};
}

export function mergeCardmarketPages(existing=[],incoming=[]) {
  const byPage=new Map(existing.map(p=>[`${p.seller.toLowerCase()}|${p.scope}|${p.page}`,p]));
  for(const p of incoming){if(p.status!=='captured')continue;const key=`${p.seller.toLowerCase()}|${p.scope}|${p.page}`;if(!byPage.has(key)||Date.parse(p.observed_at)>=Date.parse(byPage.get(key).observed_at))byPage.set(key,p);}
  if(byPage.size>500)throw Error('Capture limit reached. Export these pages before starting another scan.');
  return [...byPage.values()];
}

export function cardmarketRows(pages,seller) {
  const rows=new Map();
  for(const p of [...pages].sort((a,b)=>Date.parse(a.observed_at)-Date.parse(b.observed_at))){
    if(p.seller!==seller)continue;
    for(const r of p.rows)rows.set(r.article_id,{...r,seller:p.seller,source_url:p.url});
  }
  return [...rows.values()];
}

export function importCardmarketHar(har,parseDocument) {
  if(!Array.isArray(har?.log?.entries))throw Error('Choose a HAR or a Collectish Cardmarket capture.');
  const pages=[];let blocked=0,unreadable=0;
  for(const e of har.log.entries){
    let u;try{u=new URL(e.request?.url);}catch{continue;}
    if(u.hostname!=='www.cardmarket.com'||!u.pathname.includes('/Offers/Singles'))continue;
    const c=e.response?.content;if(!c?.text||!String(c.mimeType).includes('html'))continue;
    if(e.response.status!==200){blocked++;continue;}
    const markup=c.encoding==='base64'?new TextDecoder().decode(Uint8Array.from(atob(c.text),x=>x.charCodeAt(0))):c.text;
    try{const p=captureCardmarketDocument(parseDocument(markup),u.href,e.startedDateTime);
      if(p.status==='blocked')blocked++;else pages.push(p);
    }catch{unreadable++;}
  }
  if(!pages.length)throw Error('No successful seller inventory pages found in this HAR.');
  return {pages:mergeCardmarketPages([],pages),blocked,unreadable};
}
