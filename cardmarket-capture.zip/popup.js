import {captureCardmarketDocument,mergeCardmarketPages} from './capture.js';
const status=document.getElementById('status'),capture=document.getElementById('capture');
const read=async()=>(await chrome.storage.local.get('pages')).pages||[];
async function summary(){const pages=await read();status.textContent=`${pages.length} pages saved on this device.`;}
capture.onclick=async()=>{
 capture.disabled=true;
 try{
  const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
  if(!/^https:\/\/www\.cardmarket\.com\//.test(tab?.url||''))throw Error('Open a Cardmarket seller inventory page first.');
  const [{result}]=await chrome.scripting.executeScript({target:{tabId:tab.id},func:captureCardmarketDocument,args:[null,tab.url,new Date().toISOString()]});
  if(result.status==='blocked'){status.textContent=result.message;return;}
  const pages=mergeCardmarketPages(await read(),[result]);await chrome.storage.local.set({pages});
  status.textContent=`${result.seller}: captured ${result.rows.length} offers on page ${result.page}. ${pages.length} pages saved. Navigate normally to capture more.`;
 }catch(e){status.textContent=e.message;}finally{capture.disabled=false;}
};
document.getElementById('export').onclick=async()=>{const pages=await read();if(!pages.length){status.textContent='Capture a seller page first.';return;}const blob=new Blob([JSON.stringify({schema:'collectish-cardmarket-capture-v1',pages})],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='cardmarket-capture.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),10000);};
document.getElementById('clear').onclick=async()=>{if(confirm('Clear saved captures on this device? Export first to keep a copy.')){await chrome.storage.local.remove('pages');await summary();}};
summary();
